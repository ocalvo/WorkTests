#include <windows.h>
#include <winrt.h>
#include <wrl\client.h>
#include <wrl\event.h>

#include <wrl\implements.h> // PPP
#include <wrl\module.h>     // PPP
#include <wrl\ftm.h>        // PPP


#include <windowsstringp.h>
#include <windows.ui.xaml.h>
#include <windows.ui.xaml-private.h>
#include <time.h>
#include <shellapi.h> // ShellExecute
#include <pathcch.h> // PathCchRemoveFileSpec, PathCchCombine
#include <mrmcore.h> // MRT
#include <mrmcore_i.c> // MRT does not publish a lib with their GUIDs. We have to include the file directly.
#include <windows.ui.xaml.hosting.xamlpresentercom.h> // IXamlPresenterResources
#include <Windows.ApplicationModel.Resources.Core.Private.h> // IResourceManagerStaticInternal
#include <displayinformation.h> // IDisplayInformationStatics, IDisplayInformation
#include <windows.ui.composition.h> // ICompositionCapabilities, ICompositionCapabilitiesStatics
#include <UIViewSettings.h> // IUIViewSettingsStatics, IUIViewSettings

HANDLE g_hShutdownEvent = NULL;
UINT   g_uUIThreadCount = 0;

HANDLE CreateNewWindow();

using Windows::Foundation::GetActivationFactory;
using Windows::Foundation::ActivateInstance;
using Microsoft::WRL::ComPtr;
using Microsoft::WRL::Callback;
using Windows::Internal::String;
using Windows::Internal::StringReference;
using Windows::UI::Xaml::Hosting::IXamlPresenterStatics;
using Windows::UI::Xaml::Hosting::IXamlPresenterStatics3;
using Windows::UI::Xaml::Hosting::IXamlPresenter;
using Windows::UI::Xaml::Hosting::IXamlBridgeStatics;
using Windows::UI::Xaml::Hosting::IXamlBridge;

using namespace Microsoft::WRL; // PPP
using namespace Windows::Foundation; // PPP
using namespace Windows::Internal; // PPP
using namespace Windows::UI; // PPP
using namespace Windows::UI::Core; // PPP

#define IFC(x)                                          \
{                                                       \
    hr = (x);                                           \
    if (FAILED(hr))                                     \
    {                                                   \
        goto Cleanup;                                   \
    }                                                   \
}

class AutoApartmentInitialize
{
public:
    AutoApartmentInitialize(WINRT_INIT_TYPE initType)
    {
        m_fUninitNeeded = SUCCEEDED(
            Windows::Foundation::Initialize(initType));
    }
    
    ~AutoApartmentInitialize()
    {
        if (m_fUninitNeeded)
        {
            Windows::Foundation::Uninitialize();
        }
    }

private:
    BOOL m_fUninitNeeded;
};

AutoApartmentInitialize g_AutoApartmentInitialize(RO_INIT_MULTITHREADED);

_Check_return_ HRESULT InitializeXamlBridge(_Outptr_ Windows::UI::Xaml::Hosting::IXamlBridge** ppXamlBridge)
{
    HRESULT hr = S_OK;

    ComPtr<IXamlBridgeStatics> spXamlBridgeStatics;
    INT hostHwnd;
    ComPtr<IXamlBridge> spXamlBridge;

    IFC(GetActivationFactory(StringReference(RuntimeClass_Windows_UI_Xaml_Hosting_XamlBridge).Get(), &spXamlBridgeStatics));
    IFC(spXamlBridgeStatics->CreateForParentHwnd(NULL, &hostHwnd, &spXamlBridge));

    IFC(spXamlBridge->InitializeBridge());

    *ppXamlBridge = spXamlBridge.Detach();
    
    MoveWindow(reinterpret_cast<HWND>(hostHwnd), 100, 100, 1000, 1500, TRUE);

Cleanup:
    return hr;
}

template <class T> _Check_return_ HRESULT FindName(_In_ IInspectable* pRoot, _In_ WCHAR* wszName, _Outptr_ T** ppOut)
{
    HRESULT hr = S_OK;
    
    ComPtr<Windows::UI::Xaml::IFrameworkElement> spRootAsFE;
    Windows::Internal::StringReference name(wszName);
    ComPtr<IInspectable> spInspectable;
    ComPtr<T> spOut;
    
    IFC(pRoot->QueryInterface(__uuidof(Windows::UI::Xaml::IFrameworkElement), &spRootAsFE));
    
    IFC(spRootAsFE->FindName(name.Get(), &spInspectable));
    IFC(spInspectable.As(&spOut));
    
    *ppOut = spOut.Detach();    
    
Cleanup:
    return hr;
}


HRESULT OnTimeButtonClick(_In_ IInspectable* pSender, _In_ Windows::UI::Xaml::IRoutedEventArgs* pArgs)
{
    HRESULT hr = S_OK;
    
    ComPtr<Windows::UI::Xaml::IDependencyObject> spSenderAsDO;
    Windows::Internal::StringReference visualTreeHelperAcid(RuntimeClass_Windows_UI_Xaml_Media_VisualTreeHelper);    
    ComPtr<Windows::UI::Xaml::Media::IVisualTreeHelperStatics> spVisualTreeHelper;
    ComPtr<Windows::UI::Xaml::IDependencyObject> spRootAsDO;
    ComPtr<Windows::UI::Xaml::Controls::ITextBlock> spTextBlock;

    WCHAR timeBuffer[50];
    WCHAR dateBuffer[50];
    WCHAR buffer[100];
        
    IFC(pSender->QueryInterface(__uuidof(Windows::UI::Xaml::IDependencyObject), &spSenderAsDO));
    
    IFC(Windows::Foundation::GetActivationFactory(visualTreeHelperAcid.Get(), &spVisualTreeHelper));

    IFC(spVisualTreeHelper->GetParent(spSenderAsDO.Get(), &spRootAsDO));
    
    IFC(FindName<Windows::UI::Xaml::Controls::ITextBlock>(spRootAsDO.Get(), L"timetextblock", &spTextBlock));
    
    _wstrtime_s(timeBuffer, 50);
    _wstrdate_s(dateBuffer, 50);
    wsprintf(buffer, L"%s %s", dateBuffer, timeBuffer);

    IFC(spTextBlock->put_Text(Windows::Internal::StringReference(buffer).Get()));
    
Cleanup:
    return hr;
}

HRESULT OnGetForCurrentViewButtonClick(_In_ IInspectable* pSender, _In_ Windows::UI::Xaml::IRoutedEventArgs* pArgs)
{   
    HRESULT hr = S_OK;
    ComPtr<Windows::Graphics::Display::IDisplayInformationStatics> spDisplayInformationStatics;
    ComPtr<Windows::Graphics::Display::IDisplayInformation> spDisplayInformation;
    ComPtr<Windows::Graphics::Display::IDisplayInformation2> spDisplayInformation2;

    ComPtr<Windows::UI::Core::ICoreWindowStatic> spCoreWindowStatic;
    ComPtr<Windows::UI::Core::ICoreWindow> spCoreWindow;

    ComPtr<Windows::UI::Composition::ICompositionCapabilitiesStatics> spCompositionCapabilitiesStatics;
    ComPtr<Windows::UI::Composition::ICompositionCapabilities> spCompositionCapabilities;

    ComPtr<Windows::UI::ViewManagement::IUIViewSettingsStatics> spViewSettingsStatics;
    ComPtr<Windows::UI::ViewManagement::IUIViewSettings> spViewSettings;

    double scaleFactor;

    IFC(Windows::Foundation::GetActivationFactory(Windows::Internal::StringReference(RuntimeClass_Windows_Graphics_Display_DisplayInformation).Get(), &spDisplayInformationStatics));
    IFC(spDisplayInformationStatics->GetForCurrentView(&spDisplayInformation));
    IFC(spDisplayInformation.As(&spDisplayInformation2));
    IFC(spDisplayInformation2->get_RawPixelsPerViewPixel(&scaleFactor));

    IFC(Windows::Foundation::GetActivationFactory(Windows::Internal::StringReference(RuntimeClass_Windows_UI_Core_CoreWindow).Get(), &spCoreWindowStatic));
    IFC(spCoreWindowStatic->GetForCurrentThread(&spCoreWindow));

    IFC(Windows::Foundation::GetActivationFactory(Windows::Internal::StringReference(RuntimeClass_Windows_UI_Composition_CompositionCapabilities).Get(), &spCompositionCapabilitiesStatics));
    IFC(spCompositionCapabilitiesStatics->GetForCurrentView(&spCompositionCapabilities));

    IFC(Windows::Foundation::GetActivationFactory(Windows::Internal::StringReference(RuntimeClass_Windows_UI_ViewManagement_UIViewSettings).Get(), &spViewSettingsStatics));
    IFC(spViewSettingsStatics->GetForCurrentView(&spViewSettings));

Cleanup:
    return hr;
}

HRESULT OnWindowButtonClick(_In_ IInspectable* pSender, _In_ Windows::UI::Xaml::IRoutedEventArgs* pArgs)
{
    HRESULT hr = S_OK;

    CreateNewWindow();
//Cleanup:
    return hr;
}
    


_Check_return_ HRESULT HookUpButtons(_In_ IInspectable* pRootVisual)
{
    HRESULT hr = S_OK;
    
    ComPtr<Windows::UI::Xaml::Controls::Primitives::IButtonBase> spButton;
    EventRegistrationToken eventToken;
    
    IFC(FindName<Windows::UI::Xaml::Controls::Primitives::IButtonBase>(pRootVisual, L"windowbutton", &spButton));
    IFC(spButton->add_Click(Microsoft::WRL::Callback<Windows::UI::Xaml::IRoutedEventHandler>(OnWindowButtonClick).Get(), &eventToken));

    IFC(FindName<Windows::UI::Xaml::Controls::Primitives::IButtonBase>(pRootVisual, L"timebutton", &spButton));
    IFC(spButton->add_Click(Microsoft::WRL::Callback<Windows::UI::Xaml::IRoutedEventHandler>(OnTimeButtonClick).Get(), &eventToken));

    IFC(FindName<Windows::UI::Xaml::Controls::Primitives::IButtonBase>(pRootVisual, L"getforcurrentviewbutton", &spButton));
    IFC(spButton->add_Click(Microsoft::WRL::Callback<Windows::UI::Xaml::IRoutedEventHandler>(OnGetForCurrentViewButtonClick).Get(), &eventToken));
    
Cleanup:
    return hr;
}

_Check_return_ HRESULT UpdateWindowSizeTextBox()
{
    HRESULT hr = S_OK;
    ComPtr<Windows::UI::Xaml::IWindowStatics> spWindowStatics;
    ComPtr<Windows::UI::Xaml::IWindow> spWindow;
    ComPtr<Windows::UI::Xaml::IUIElement> spContent;
    ComPtr<Windows::UI::Xaml::Controls::ITextBlock> spTextBlock;
    Windows::Foundation::Rect bounds;
    WCHAR wszBuffer[100];
    
    IFC(Windows::Foundation::GetActivationFactory(StringReference(RuntimeClass_Windows_UI_Xaml_Window).Get(), &spWindowStatics));
    IFC(spWindowStatics->get_Current(&spWindow));
    IFC(spWindow->get_Content(&spContent));
    if (!spContent)
    {
        goto Cleanup;
    }

    IFC(FindName<Windows::UI::Xaml::Controls::ITextBlock>(spContent.Get(), L"sizetextblock", &spTextBlock));

    IFC(spWindow->get_Bounds(&bounds));
    wsprintf(
		wszBuffer, 
		L"X=%d Y=%d Width=%d Height=%d", 
		static_cast<int>(bounds.X), 
		static_cast<int>(bounds.Y), 
		static_cast<int>(bounds.Width), 
		static_cast<int>(bounds.Height));

    IFC(spTextBlock->put_Text(Windows::Internal::StringReference(wszBuffer).Get()));
    
Cleanup:
    return hr;
}

_Check_return_ HRESULT OnWindowSizeChanged(_In_ IInspectable* pSender, _In_ Windows::UI::Core::IWindowSizeChangedEventArgs* pArgs)
{
    return UpdateWindowSizeTextBox();
}

_Check_return_ HRESULT RegisterWindowSizeChanged()
{
    HRESULT hr = S_OK;
    ComPtr<Windows::UI::Xaml::IWindowStatics> spWindowStatics;
    ComPtr<Windows::UI::Xaml::IWindow> spWindow;
    EventRegistrationToken eventToken;
    
    IFC(Windows::Foundation::GetActivationFactory(StringReference(RuntimeClass_Windows_UI_Xaml_Window).Get(), &spWindowStatics));
    IFC(spWindowStatics->get_Current(&spWindow));
    
    IFC(spWindow->add_SizeChanged(Microsoft::WRL::Callback<Windows::UI::Xaml::IWindowSizeChangedEventHandler>(OnWindowSizeChanged).Get(), &eventToken));
    
Cleanup:
    return hr;
}

_Check_return_ HRESULT SetupInking(_In_ IInspectable* pRootVisual)
{
    HRESULT hr = S_OK;
    ComPtr<Windows::UI::Xaml::Controls::IInkCanvas> spInkCanvas;
    ComPtr<Windows::UI::Input::Inking::IInkPresenter> spInkPresenter;
    ComPtr<Windows::UI::Input::Inking::IInkDrawingAttributes> spInkDrawingAttributes;
    ComPtr<Windows::UI::IColorsStatics> spColorsStatics;
    Windows::UI::Color color;

    IFC(FindName<Windows::UI::Xaml::Controls::IInkCanvas>(pRootVisual, L"inkcanvas", &spInkCanvas));
    IFC(spInkCanvas->get_InkPresenter(&spInkPresenter));
    IFC(spInkPresenter->put_InputDeviceTypes(CoreInputDeviceTypes::CoreInputDeviceTypes_Pen | CoreInputDeviceTypes::CoreInputDeviceTypes_Touch | CoreInputDeviceTypes::CoreInputDeviceTypes_Mouse));

    IFC(ActivateInstance(StringReference(RuntimeClass_Windows_UI_Input_Inking_InkDrawingAttributes).Get(), &spInkDrawingAttributes));
    IFC(GetActivationFactory(StringReference(RuntimeClass_Windows_UI_Colors).Get(), &spColorsStatics));
    IFC(spColorsStatics->get_White(&color));
    IFC(spInkDrawingAttributes->put_Color(color));
    IFC(spInkPresenter->UpdateDefaultDrawingAttributes(spInkDrawingAttributes.Get()));

Cleanup:
    return hr;
}

_Check_return_ HRESULT SetupMedia(_In_ IInspectable* pRootVisual)
{
    HRESULT hr = S_OK;
    ComPtr<Windows::UI::Xaml::Controls::IMediaPlayerElement> spMediaPlayerElement;
    ComPtr<Windows::Media::Playback::IMediaPlayer> spMediaPlayer;

    IFC(FindName<Windows::UI::Xaml::Controls::IMediaPlayerElement>(pRootVisual, L"mediaplayerelement", &spMediaPlayerElement));
    
    IFC(spMediaPlayerElement->get_MediaPlayer(&spMediaPlayer));
    IFC(spMediaPlayer->put_IsLoopingEnabled(true));

Cleanup:
    return hr;
}

_Check_return_ HRESULT CreateXamlContent(_Outptr_ Windows::UI::Xaml::IUIElement** ppContent)
{
    HRESULT hr = S_OK;
    
    ComPtr<Windows::Foundation::IUriRuntimeClassFactory> spUriFactory;
    ComPtr<Windows::Foundation::IUriRuntimeClass> spResourceUri;
    ComPtr<Windows::UI::Xaml::Controls::IStackPanel> spContent;
    ComPtr<Windows::UI::Xaml::IApplicationStatics> spAppStatics;
    ComPtr<Windows::UI::Xaml::Media::Animation::IStoryboard> spStoryboard;
    ComPtr<Windows::UI::Xaml::IUIElement> spContentAsUIElement;

    IFC(GetActivationFactory(StringReference(RuntimeClass_Windows_Foundation_Uri).Get(), &spUriFactory));
    IFC(spUriFactory->CreateUri(StringReference(L"ms-resource:///Files/content.xaml").Get(), &spResourceUri));
    
    IFC(ActivateInstance(StringReference(RuntimeClass_Windows_UI_Xaml_Controls_StackPanel).Get(), &spContent));
    
    IFC(GetActivationFactory(StringReference(RuntimeClass_Windows_UI_Xaml_Application).Get(), &spAppStatics));
    IFC(spAppStatics->LoadComponent(spContent.Get(), spResourceUri.Get()));
    
    IFC(HookUpButtons(spContent.Get()));
    
    IFC(FindName<Windows::UI::Xaml::Media::Animation::IStoryboard>(spContent.Get(), L"MyStoryboard", &spStoryboard));
    IFC(spStoryboard->Begin());

    IFC(SetupInking(spContent.Get()));
    IFC(SetupMedia(spContent.Get()));

    IFC(spContent.As(&spContentAsUIElement));
    *ppContent = spContentAsUIElement.Detach();

Cleanup:
    return hr;
}

_Check_return_ HRESULT RunMessageLoop()
{
    HRESULT hr = S_OK;
    ComPtr<Windows::UI::Core::ICoreWindowStatic> spCoreWindowStatic;
    ComPtr<Windows::UI::Core::ICoreWindow> spCoreWindow;
    ComPtr<Windows::UI::Core::ICoreDispatcher> spCoreDispatcher;

    IFC(Windows::Foundation::GetActivationFactory(Windows::Internal::StringReference(RuntimeClass_Windows_UI_Core_CoreWindow).Get(), &spCoreWindowStatic));
    IFC(spCoreWindowStatic->GetForCurrentThread(&spCoreWindow));
    IFC(spCoreWindow->get_Dispatcher(&spCoreDispatcher));
    IFC(spCoreDispatcher->ProcessEvents(Windows::UI::Core::CoreProcessEventsOption::CoreProcessEventsOption_ProcessUntilQuit));


    /*
    MSG msg;
    BOOL bRet;

    while ((bRet = GetMessage(&msg, NULL, 0, 0)) != 0)
    {
        if (-1 == bRet)
        {
            IFC(E_FAIL);
        }

        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
    */

Cleanup:
    return hr;
}

DWORD WINAPI UIThreadProc(LPVOID)
{
    HRESULT hr = S_OK;
    ComPtr<ICoreWindow> spCoreWindow;
    ComPtr<IXamlBridge> spXamlBridge;
    ComPtr<Windows::UI::Xaml::IUIElement> spXamlContent;
    ComPtr<Windows::Foundation::IClosable> spClosable;

    InterlockedIncrement(&g_uUIThreadCount);

    IFC(Windows::Foundation::Initialize(RO_INIT_SINGLETHREADED));
    if (!EnableMouseInPointer(TRUE))
    {
        IFC(E_FAIL);
    }

    IFC(InitializeXamlBridge(&spXamlBridge));
    IFC(RegisterWindowSizeChanged());
    IFC(CreateXamlContent(&spXamlContent));

    IFC(spXamlBridge->put_Content(spXamlContent.Get()));
    spXamlContent = nullptr;
    IFC(UpdateWindowSizeTextBox());

    IFC(RunMessageLoop());
    
    IFC(spXamlBridge.As(&spClosable));
    IFC(spClosable->Close());

Cleanup:
    Windows::Foundation::Uninitialize();
    
    InterlockedDecrement(&g_uUIThreadCount);
    SetEvent(g_hShutdownEvent);

    return SUCCEEDED(hr) ? 0 : 1;
}

HANDLE CreateNewWindow()
{
    return CreateThread(NULL, 0, UIThreadProc, NULL, 0, NULL);
}

int APIENTRY wWinMain(
    HINSTANCE hInstance,
    HINSTANCE hPrevInstance,
    LPTSTR lpCmdLine,
    int nCmdShow)
{
    SetProcessDPIAware();

    g_hShutdownEvent = CreateEvent(NULL, FALSE, FALSE, NULL);

    CreateNewWindow();
    
    while (true) 
    { 
        WaitForSingleObject(g_hShutdownEvent, INFINITE);
        if (g_uUIThreadCount == 0)
        {
            break;
        }
    }
    
    CloseHandle(g_hShutdownEvent);
    
    return 0;
}
